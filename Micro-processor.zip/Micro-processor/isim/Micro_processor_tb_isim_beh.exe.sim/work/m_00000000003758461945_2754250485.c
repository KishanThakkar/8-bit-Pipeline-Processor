/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif



static void Gate_20_0(char *t0)
{
    char t4[8];
    char t12[8];
    char t15[8];
    char t40[8];
    char t43[8];
    char t68[8];
    char t71[8];
    char t98[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t13;
    char *t14;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    char *t41;
    char *t42;
    char *t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    char *t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    char *t58;
    char *t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    char *t69;
    char *t70;
    char *t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    char *t85;
    char *t86;
    char *t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    char *t96;
    char *t97;
    char *t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    char *t106;
    char *t107;
    char *t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;

LAB0:    t1 = (t0 + 3808U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t4 + 4);
    t5 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 15);
    t8 = (t7 & 1);
    *((unsigned int *)t4) = t8;
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 15);
    t11 = (t10 & 1);
    *((unsigned int *)t2) = t11;
    t13 = (t0 + 1048U);
    t14 = *((char **)t13);
    memset(t15, 0, 8);
    t13 = (t15 + 4);
    t16 = (t14 + 4);
    t17 = *((unsigned int *)t14);
    t18 = (t17 >> 16);
    t19 = (t18 & 1);
    *((unsigned int *)t15) = t19;
    t20 = *((unsigned int *)t16);
    t21 = (t20 >> 16);
    t22 = (t21 & 1);
    *((unsigned int *)t13) = t22;
    memset(t12, 0, 8);
    t23 = (t15 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (~(t24));
    t26 = *((unsigned int *)t15);
    t27 = (t26 & t25);
    t28 = (t27 & 1U);
    if (t28 != 0)
        goto LAB7;

LAB5:    if (*((unsigned int *)t23) == 0)
        goto LAB4;

LAB6:    t29 = (t12 + 4);
    *((unsigned int *)t12) = 1;
    *((unsigned int *)t29) = 1;

LAB7:    t30 = (t12 + 4);
    t31 = (t15 + 4);
    t32 = *((unsigned int *)t15);
    t33 = (~(t32));
    *((unsigned int *)t12) = t33;
    *((unsigned int *)t30) = 0;
    if (*((unsigned int *)t31) != 0)
        goto LAB9;

LAB8:    t38 = *((unsigned int *)t12);
    *((unsigned int *)t12) = (t38 & 1U);
    t39 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t39 & 1U);
    t41 = (t0 + 1048U);
    t42 = *((char **)t41);
    memset(t43, 0, 8);
    t41 = (t43 + 4);
    t44 = (t42 + 4);
    t45 = *((unsigned int *)t42);
    t46 = (t45 >> 17);
    t47 = (t46 & 1);
    *((unsigned int *)t43) = t47;
    t48 = *((unsigned int *)t44);
    t49 = (t48 >> 17);
    t50 = (t49 & 1);
    *((unsigned int *)t41) = t50;
    memset(t40, 0, 8);
    t51 = (t43 + 4);
    t52 = *((unsigned int *)t51);
    t53 = (~(t52));
    t54 = *((unsigned int *)t43);
    t55 = (t54 & t53);
    t56 = (t55 & 1U);
    if (t56 != 0)
        goto LAB13;

LAB11:    if (*((unsigned int *)t51) == 0)
        goto LAB10;

LAB12:    t57 = (t40 + 4);
    *((unsigned int *)t40) = 1;
    *((unsigned int *)t57) = 1;

LAB13:    t58 = (t40 + 4);
    t59 = (t43 + 4);
    t60 = *((unsigned int *)t43);
    t61 = (~(t60));
    *((unsigned int *)t40) = t61;
    *((unsigned int *)t58) = 0;
    if (*((unsigned int *)t59) != 0)
        goto LAB15;

LAB14:    t66 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t66 & 1U);
    t67 = *((unsigned int *)t58);
    *((unsigned int *)t58) = (t67 & 1U);
    t69 = (t0 + 1048U);
    t70 = *((char **)t69);
    memset(t71, 0, 8);
    t69 = (t71 + 4);
    t72 = (t70 + 4);
    t73 = *((unsigned int *)t70);
    t74 = (t73 >> 18);
    t75 = (t74 & 1);
    *((unsigned int *)t71) = t75;
    t76 = *((unsigned int *)t72);
    t77 = (t76 >> 18);
    t78 = (t77 & 1);
    *((unsigned int *)t69) = t78;
    memset(t68, 0, 8);
    t79 = (t71 + 4);
    t80 = *((unsigned int *)t79);
    t81 = (~(t80));
    t82 = *((unsigned int *)t71);
    t83 = (t82 & t81);
    t84 = (t83 & 1U);
    if (t84 != 0)
        goto LAB19;

LAB17:    if (*((unsigned int *)t79) == 0)
        goto LAB16;

LAB18:    t85 = (t68 + 4);
    *((unsigned int *)t68) = 1;
    *((unsigned int *)t85) = 1;

LAB19:    t86 = (t68 + 4);
    t87 = (t71 + 4);
    t88 = *((unsigned int *)t71);
    t89 = (~(t88));
    *((unsigned int *)t68) = t89;
    *((unsigned int *)t86) = 0;
    if (*((unsigned int *)t87) != 0)
        goto LAB21;

LAB20:    t94 = *((unsigned int *)t68);
    *((unsigned int *)t68) = (t94 & 1U);
    t95 = *((unsigned int *)t86);
    *((unsigned int *)t86) = (t95 & 1U);
    t96 = (t0 + 1048U);
    t97 = *((char **)t96);
    memset(t98, 0, 8);
    t96 = (t98 + 4);
    t99 = (t97 + 4);
    t100 = *((unsigned int *)t97);
    t101 = (t100 >> 19);
    t102 = (t101 & 1);
    *((unsigned int *)t98) = t102;
    t103 = *((unsigned int *)t99);
    t104 = (t103 >> 19);
    t105 = (t104 & 1);
    *((unsigned int *)t96) = t105;
    t106 = (t0 + 5000);
    t107 = (t106 + 56U);
    t108 = *((char **)t107);
    t109 = (t108 + 56U);
    t110 = *((char **)t109);
    xsi_vlog_AndGate(t110, 5, t4, t12, t40, t68, t98);
    t111 = (t0 + 5000);
    xsi_driver_vfirst_trans(t111, 0, 0);
    t112 = (t0 + 4872);
    *((int *)t112) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t12) = 1;
    goto LAB7;

LAB9:    t34 = *((unsigned int *)t12);
    t35 = *((unsigned int *)t31);
    *((unsigned int *)t12) = (t34 | t35);
    t36 = *((unsigned int *)t30);
    t37 = *((unsigned int *)t31);
    *((unsigned int *)t30) = (t36 | t37);
    goto LAB8;

LAB10:    *((unsigned int *)t40) = 1;
    goto LAB13;

LAB15:    t62 = *((unsigned int *)t40);
    t63 = *((unsigned int *)t59);
    *((unsigned int *)t40) = (t62 | t63);
    t64 = *((unsigned int *)t58);
    t65 = *((unsigned int *)t59);
    *((unsigned int *)t58) = (t64 | t65);
    goto LAB14;

LAB16:    *((unsigned int *)t68) = 1;
    goto LAB19;

LAB21:    t90 = *((unsigned int *)t68);
    t91 = *((unsigned int *)t87);
    *((unsigned int *)t68) = (t90 | t91);
    t92 = *((unsigned int *)t86);
    t93 = *((unsigned int *)t87);
    *((unsigned int *)t86) = (t92 | t93);
    goto LAB20;

}

static void Gate_21_1(char *t0)
{
    char t3[8];
    char t5[8];
    char t30[8];
    char t33[8];
    char t60[8];
    char t68[8];
    char t71[8];
    char t98[8];
    char t106[8];
    char *t1;
    char *t2;
    char *t4;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t31;
    char *t32;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    char *t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    char *t58;
    char *t59;
    char *t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    char *t69;
    char *t70;
    char *t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    char *t85;
    char *t86;
    char *t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    char *t96;
    char *t97;
    char *t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    char *t107;
    char *t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    char *t114;
    char *t115;
    char *t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    char *t125;
    char *t126;
    char *t127;
    char *t128;
    char *t129;
    char *t130;
    char *t131;

LAB0:    t1 = (t0 + 4056U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1048U);
    t4 = *((char **)t2);
    memset(t5, 0, 8);
    t2 = (t5 + 4);
    t6 = (t4 + 4);
    t7 = *((unsigned int *)t4);
    t8 = (t7 >> 15);
    t9 = (t8 & 1);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 15);
    t12 = (t11 & 1);
    *((unsigned int *)t2) = t12;
    memset(t3, 0, 8);
    t13 = (t5 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t5);
    t17 = (t16 & t15);
    t18 = (t17 & 1U);
    if (t18 != 0)
        goto LAB7;

LAB5:    if (*((unsigned int *)t13) == 0)
        goto LAB4;

LAB6:    t19 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t19) = 1;

LAB7:    t20 = (t3 + 4);
    t21 = (t5 + 4);
    t22 = *((unsigned int *)t5);
    t23 = (~(t22));
    *((unsigned int *)t3) = t23;
    *((unsigned int *)t20) = 0;
    if (*((unsigned int *)t21) != 0)
        goto LAB9;

LAB8:    t28 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t28 & 1U);
    t29 = *((unsigned int *)t20);
    *((unsigned int *)t20) = (t29 & 1U);
    t31 = (t0 + 1048U);
    t32 = *((char **)t31);
    memset(t33, 0, 8);
    t31 = (t33 + 4);
    t34 = (t32 + 4);
    t35 = *((unsigned int *)t32);
    t36 = (t35 >> 16);
    t37 = (t36 & 1);
    *((unsigned int *)t33) = t37;
    t38 = *((unsigned int *)t34);
    t39 = (t38 >> 16);
    t40 = (t39 & 1);
    *((unsigned int *)t31) = t40;
    memset(t30, 0, 8);
    t41 = (t33 + 4);
    t42 = *((unsigned int *)t41);
    t43 = (~(t42));
    t44 = *((unsigned int *)t33);
    t45 = (t44 & t43);
    t46 = (t45 & 1U);
    if (t46 != 0)
        goto LAB13;

LAB11:    if (*((unsigned int *)t41) == 0)
        goto LAB10;

LAB12:    t47 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t47) = 1;

LAB13:    t48 = (t30 + 4);
    t49 = (t33 + 4);
    t50 = *((unsigned int *)t33);
    t51 = (~(t50));
    *((unsigned int *)t30) = t51;
    *((unsigned int *)t48) = 0;
    if (*((unsigned int *)t49) != 0)
        goto LAB15;

LAB14:    t56 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t56 & 1U);
    t57 = *((unsigned int *)t48);
    *((unsigned int *)t48) = (t57 & 1U);
    t58 = (t0 + 1048U);
    t59 = *((char **)t58);
    memset(t60, 0, 8);
    t58 = (t60 + 4);
    t61 = (t59 + 4);
    t62 = *((unsigned int *)t59);
    t63 = (t62 >> 17);
    t64 = (t63 & 1);
    *((unsigned int *)t60) = t64;
    t65 = *((unsigned int *)t61);
    t66 = (t65 >> 17);
    t67 = (t66 & 1);
    *((unsigned int *)t58) = t67;
    t69 = (t0 + 1048U);
    t70 = *((char **)t69);
    memset(t71, 0, 8);
    t69 = (t71 + 4);
    t72 = (t70 + 4);
    t73 = *((unsigned int *)t70);
    t74 = (t73 >> 18);
    t75 = (t74 & 1);
    *((unsigned int *)t71) = t75;
    t76 = *((unsigned int *)t72);
    t77 = (t76 >> 18);
    t78 = (t77 & 1);
    *((unsigned int *)t69) = t78;
    memset(t68, 0, 8);
    t79 = (t71 + 4);
    t80 = *((unsigned int *)t79);
    t81 = (~(t80));
    t82 = *((unsigned int *)t71);
    t83 = (t82 & t81);
    t84 = (t83 & 1U);
    if (t84 != 0)
        goto LAB19;

LAB17:    if (*((unsigned int *)t79) == 0)
        goto LAB16;

LAB18:    t85 = (t68 + 4);
    *((unsigned int *)t68) = 1;
    *((unsigned int *)t85) = 1;

LAB19:    t86 = (t68 + 4);
    t87 = (t71 + 4);
    t88 = *((unsigned int *)t71);
    t89 = (~(t88));
    *((unsigned int *)t68) = t89;
    *((unsigned int *)t86) = 0;
    if (*((unsigned int *)t87) != 0)
        goto LAB21;

LAB20:    t94 = *((unsigned int *)t68);
    *((unsigned int *)t68) = (t94 & 1U);
    t95 = *((unsigned int *)t86);
    *((unsigned int *)t86) = (t95 & 1U);
    t96 = (t0 + 1048U);
    t97 = *((char **)t96);
    memset(t98, 0, 8);
    t96 = (t98 + 4);
    t99 = (t97 + 4);
    t100 = *((unsigned int *)t97);
    t101 = (t100 >> 19);
    t102 = (t101 & 1);
    *((unsigned int *)t98) = t102;
    t103 = *((unsigned int *)t99);
    t104 = (t103 >> 19);
    t105 = (t104 & 1);
    *((unsigned int *)t96) = t105;
    t107 = (t0 + 2328U);
    t108 = *((char **)t107);
    memset(t106, 0, 8);
    t107 = (t108 + 4);
    t109 = *((unsigned int *)t107);
    t110 = (~(t109));
    t111 = *((unsigned int *)t108);
    t112 = (t111 & t110);
    t113 = (t112 & 1U);
    if (t113 != 0)
        goto LAB25;

LAB23:    if (*((unsigned int *)t107) == 0)
        goto LAB22;

LAB24:    t114 = (t106 + 4);
    *((unsigned int *)t106) = 1;
    *((unsigned int *)t114) = 1;

LAB25:    t115 = (t106 + 4);
    t116 = (t108 + 4);
    t117 = *((unsigned int *)t108);
    t118 = (~(t117));
    *((unsigned int *)t106) = t118;
    *((unsigned int *)t115) = 0;
    if (*((unsigned int *)t116) != 0)
        goto LAB27;

LAB26:    t123 = *((unsigned int *)t106);
    *((unsigned int *)t106) = (t123 & 1U);
    t124 = *((unsigned int *)t115);
    *((unsigned int *)t115) = (t124 & 1U);
    t125 = (t0 + 5064);
    t126 = (t125 + 56U);
    t127 = *((char **)t126);
    t128 = (t127 + 56U);
    t129 = *((char **)t128);
    xsi_vlog_AndGate(t129, 6, t3, t30, t60, t68, t98, t106);
    t130 = (t0 + 5064);
    xsi_driver_vfirst_trans(t130, 0, 0);
    t131 = (t0 + 4888);
    *((int *)t131) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t3) = 1;
    goto LAB7;

LAB9:    t24 = *((unsigned int *)t3);
    t25 = *((unsigned int *)t21);
    *((unsigned int *)t3) = (t24 | t25);
    t26 = *((unsigned int *)t20);
    t27 = *((unsigned int *)t21);
    *((unsigned int *)t20) = (t26 | t27);
    goto LAB8;

LAB10:    *((unsigned int *)t30) = 1;
    goto LAB13;

LAB15:    t52 = *((unsigned int *)t30);
    t53 = *((unsigned int *)t49);
    *((unsigned int *)t30) = (t52 | t53);
    t54 = *((unsigned int *)t48);
    t55 = *((unsigned int *)t49);
    *((unsigned int *)t48) = (t54 | t55);
    goto LAB14;

LAB16:    *((unsigned int *)t68) = 1;
    goto LAB19;

LAB21:    t90 = *((unsigned int *)t68);
    t91 = *((unsigned int *)t87);
    *((unsigned int *)t68) = (t90 | t91);
    t92 = *((unsigned int *)t86);
    t93 = *((unsigned int *)t87);
    *((unsigned int *)t86) = (t92 | t93);
    goto LAB20;

LAB22:    *((unsigned int *)t106) = 1;
    goto LAB25;

LAB27:    t119 = *((unsigned int *)t106);
    t120 = *((unsigned int *)t116);
    *((unsigned int *)t106) = (t119 | t120);
    t121 = *((unsigned int *)t115);
    t122 = *((unsigned int *)t116);
    *((unsigned int *)t115) = (t121 | t122);
    goto LAB26;

}

static void Gate_22_2(char *t0)
{
    char t4[8];
    char t14[8];
    char t24[8];
    char t32[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    char *t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    char *t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;

LAB0:    t1 = (t0 + 4304U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t4 + 4);
    t5 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 17);
    t8 = (t7 & 1);
    *((unsigned int *)t4) = t8;
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 17);
    t11 = (t10 & 1);
    *((unsigned int *)t2) = t11;
    t12 = (t0 + 1048U);
    t13 = *((char **)t12);
    memset(t14, 0, 8);
    t12 = (t14 + 4);
    t15 = (t13 + 4);
    t16 = *((unsigned int *)t13);
    t17 = (t16 >> 18);
    t18 = (t17 & 1);
    *((unsigned int *)t14) = t18;
    t19 = *((unsigned int *)t15);
    t20 = (t19 >> 18);
    t21 = (t20 & 1);
    *((unsigned int *)t12) = t21;
    t22 = (t0 + 1048U);
    t23 = *((char **)t22);
    memset(t24, 0, 8);
    t22 = (t24 + 4);
    t25 = (t23 + 4);
    t26 = *((unsigned int *)t23);
    t27 = (t26 >> 19);
    t28 = (t27 & 1);
    *((unsigned int *)t24) = t28;
    t29 = *((unsigned int *)t25);
    t30 = (t29 >> 19);
    t31 = (t30 & 1);
    *((unsigned int *)t22) = t31;
    t33 = (t0 + 2648U);
    t34 = *((char **)t33);
    memset(t32, 0, 8);
    t33 = (t34 + 4);
    t35 = *((unsigned int *)t33);
    t36 = (~(t35));
    t37 = *((unsigned int *)t34);
    t38 = (t37 & t36);
    t39 = (t38 & 1U);
    if (t39 != 0)
        goto LAB7;

LAB5:    if (*((unsigned int *)t33) == 0)
        goto LAB4;

LAB6:    t40 = (t32 + 4);
    *((unsigned int *)t32) = 1;
    *((unsigned int *)t40) = 1;

LAB7:    t41 = (t32 + 4);
    t42 = (t34 + 4);
    t43 = *((unsigned int *)t34);
    t44 = (~(t43));
    *((unsigned int *)t32) = t44;
    *((unsigned int *)t41) = 0;
    if (*((unsigned int *)t42) != 0)
        goto LAB9;

LAB8:    t49 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t49 & 1U);
    t50 = *((unsigned int *)t41);
    *((unsigned int *)t41) = (t50 & 1U);
    t51 = (t0 + 5128);
    t52 = (t51 + 56U);
    t53 = *((char **)t52);
    t54 = (t53 + 56U);
    t55 = *((char **)t54);
    xsi_vlog_AndGate(t55, 4, t4, t14, t24, t32);
    t56 = (t0 + 5128);
    xsi_driver_vfirst_trans(t56, 0, 0);
    t57 = (t0 + 4904);
    *((int *)t57) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t32) = 1;
    goto LAB7;

LAB9:    t45 = *((unsigned int *)t32);
    t46 = *((unsigned int *)t42);
    *((unsigned int *)t32) = (t45 | t46);
    t47 = *((unsigned int *)t41);
    t48 = *((unsigned int *)t42);
    *((unsigned int *)t41) = (t47 | t48);
    goto LAB8;

}

static void Gate_30_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    t1 = (t0 + 4552U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1848U);
    t3 = *((char **)t2);
    t2 = (t0 + 2008U);
    t4 = *((char **)t2);
    t2 = (t0 + 2168U);
    t5 = *((char **)t2);
    t2 = (t0 + 5192);
    t6 = (t2 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    xsi_vlog_OrGate(t9, 3, t3, t4, t5);
    t10 = (t0 + 5192);
    xsi_driver_vfirst_trans(t10, 0, 0);
    t11 = (t0 + 4920);
    *((int *)t11) = 1;

LAB1:    return;
}


extern void work_m_00000000003758461945_2754250485_init()
{
	static char *pe[] = {(void *)Gate_20_0,(void *)Gate_21_1,(void *)Gate_22_2,(void *)Gate_30_3};
	xsi_register_didat("work_m_00000000003758461945_2754250485", "isim/Micro_processor_tb_isim_beh.exe.sim/work/m_00000000003758461945_2754250485.didat");
	xsi_register_executes(pe);
}
