/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000001160127574_0897309690_2346523100_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2346523100", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2346523100.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1447805017_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1447805017", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1447805017.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3951144087_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3951144087", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3951144087.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0907506962_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0907506962", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0907506962.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1679782626_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1679782626", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1679782626.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3112807271_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3112807271", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3112807271.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0071550889_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0071550889", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0071550889.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3654622764_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3654622764", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3654622764.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1504467312_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1504467312", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1504467312.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2218426613_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2218426613", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2218426613.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2739557824_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2739557824", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2739557824.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2128383045_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2128383045", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2128383045.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3060675150_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3060675150", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3060675150.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1811475403_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1811475403", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1811475403.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1283997438_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1283997438", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1283997438.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2434721659_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2434721659", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2434721659.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0058452865_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0058452865", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0058452865.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3740086788_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3740086788", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3740086788.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1663524554_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1663524554", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1663524554.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3199305551_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3199305551", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3199305551.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3971580095_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3971580095", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3971580095.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0825186618_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0825186618", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0825186618.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2363831796_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2363831796", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2363831796.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1366551665_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1366551665", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1366551665.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0241540038_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0241540038", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0241540038.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3555934787_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3555934787", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3555934787.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1849241229_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1849241229", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1849241229.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3014653704_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3014653704", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3014653704.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3785879800_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3785879800", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3785879800.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1009854845_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1009854845", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1009854845.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2180728243_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2180728243", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2180728243.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1550687286_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1550687286", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1550687286.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0446809858_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0446809858", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0446809858.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3342278279_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3342278279", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3342278279.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3762801586_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3762801586", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3762801586.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1037111863_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1037111863", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1037111863.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4116950076_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4116950076", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4116950076.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0687175097_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0687175097", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0687175097.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0260415628_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0260415628", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0260415628.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3524491529_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3524491529", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3524491529.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3607551443_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3607551443", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3607551443.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0177210454_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0177210454", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0177210454.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2011365902_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2011365902", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2011365902.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2859850635_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2859850635", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2859850635.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0952415981_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0952415981", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0952415981.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3847384936_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3847384936", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3847384936.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2552326448_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2552326448", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2552326448.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1169666229_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1169666229", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1169666229.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3548542633_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3548542633", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3548542633.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0236236588_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0236236588", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0236236588.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1936173428_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1936173428", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1936173428.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2935058673_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2935058673", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2935058673.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1010834839_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1010834839", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1010834839.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3788948498_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3788948498", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3788948498.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2628108874_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2628108874", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2628108874.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1093868495_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1093868495", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1093868495.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3869236432_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3869236432", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3869236432.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0990446933_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0990446933", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0990446933.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1182401293_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1182401293", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1182401293.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2615990920_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2615990920", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2615990920.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0157136878_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0157136878", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0157136878.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3570101867_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3570101867", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3570101867.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2847434803_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2847434803", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2847434803.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1949217206_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1949217206", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1949217206.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0888052860_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0888052860", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0888052860.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3916973561_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3916973561", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3916973561.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1420962103_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1420962103", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1420962103.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2300899506_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2300899506", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2300899506.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3677157186_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3677157186", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3677157186.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0112864967_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0112864967", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0112864967.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3144696329_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3144696329", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3144696329.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1726389132_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1726389132", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1726389132.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0126761916_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0126761916", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0126761916.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3659063865_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3659063865", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3659063865.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1741852407_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1741852407", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1741852407.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3125041010_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3125041010", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3125041010.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3897315458_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3897315458", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3897315458.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0903514375_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0903514375", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0903514375.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2282808777_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2282808777", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2282808777.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1434860620_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1434860620", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1434860620.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0177228795_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0177228795", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0177228795.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3607532158_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3607532158", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3607532158.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1791819440_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1791819440", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1791819440.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3076138805_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3076138805", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3076138805.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3847364805_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3847364805", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3847364805.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0952432960_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0952432960", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0952432960.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2232325518_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2232325518", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2232325518.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1486375947_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1486375947", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1486375947.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0508827455_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0508827455", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0508827455.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3284324026_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3284324026", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3284324026.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3836877711_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3836877711", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3836877711.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0958710282_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0958710282", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0958710282.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4053171201_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4053171201", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4053171201.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0738239876_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0738239876", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0738239876.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0191918257_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0191918257", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0191918257.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3605440820_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3605440820", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3605440820.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3659050388_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3659050388", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3659050388.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0126776337_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0126776337", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0126776337.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2063430217_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2063430217", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2063430217.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2808851404_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2808851404", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2808851404.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0903530154_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0903530154", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0903530154.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3897302831_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3897302831", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3897302831.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2503940471_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2503940471", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2503940471.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1219084530_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1219084530", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1219084530.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2355855469_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2355855469", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2355855469.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1375558120_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1375558120", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1375558120.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1988988125_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1988988125", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1988988125.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2870695256_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2870695256", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2870695256.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1672080211_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1672080211", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1672080211.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3191812822_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3191812822", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3191812822.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2572150755_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2572150755", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2572150755.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1155087974_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1155087974", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1155087974.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3614942868_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3614942868", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3614942868.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0182550289_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0182550289", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0182550289.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2006088009_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2006088009", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2006088009.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2852430028_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2852430028", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2852430028.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0951438762_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0951438762", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0951438762.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3844281391_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3844281391", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3844281391.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2555384439_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2555384439", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2555384439.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1170656242_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1170656242", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1170656242.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1920490720_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1920490720", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1920490720.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2951644517_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2951644517", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2951644517.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3017720802_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3017720802", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3017720802.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1850219111_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1850219111", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1850219111.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2646226910_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2646226910", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2646226910.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1076686427_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1076686427", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1076686427.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1545382108_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1545382108", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1545382108.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2173333849_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2173333849", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2173333849.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3647971841_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3647971841", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3647971841.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4023304327_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4023304327", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4023304327.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0647760491_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0647760491", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0647760491.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3292533010_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3292533010", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3292533010.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0567710417_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0567710417", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0567710417.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3233136943_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3233136943", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3233136943.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3732730268_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3732730268", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3732730268.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3241732097_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3241732097", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3241732097.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1218332990_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1218332990", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1218332990.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2551636220_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2551636220", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2551636220.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1252796567_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1252796567", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1252796567.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0462025975_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0462025975", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0462025975.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2735732676_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2735732676", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2735732676.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2105519585_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2105519585", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2105519585.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2699654244_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2699654244", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2699654244.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4162048317_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4162048317", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4162048317.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0000830393_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0000830393", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0000830393.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3552871458_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3552871458", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3552871458.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3848660644_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3848660644", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3848660644.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3714446159_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3714446159", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3714446159.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1701983204_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1701983204", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1701983204.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1889426645_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1889426645", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1889426645.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3717886524_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3717886524", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3717886524.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0488855303_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0488855303", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0488855303.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0488839338_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0488839338", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0488839338.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0083458948_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0083458948", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0083458948.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2461910751_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2461910751", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2461910751.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1288543482_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1288543482", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1288543482.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3671106859_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3671106859", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3671106859.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1672912210_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1672912210", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1672912210.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0844634370_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0844634370", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0844634370.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1861314975_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1861314975", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1861314975.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1943984780_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1943984780", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1943984780.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0207647651_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0207647651", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0207647651.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2316648961_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2316648961", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2316648961.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4267297298_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4267297298", "isim/Micro_processor_tb_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4267297298.didat");
}
