/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000000303365308_3238527249_init();
    xilinxcorelib_ver_m_00000000001358910285_2123670738_init();
    xilinxcorelib_ver_m_00000000001358910285_1298878945_init();
    xilinxcorelib_ver_m_00000000001687936702_0873297193_init();
    xilinxcorelib_ver_m_00000000000277421008_3547948864_init();
    xilinxcorelib_ver_m_00000000001603977570_1771200655_init();
    work_m_00000000003388451136_0929306500_init();
    work_m_00000000004232097084_0111149329_init();
    work_m_00000000003406651060_2013924567_init();
    work_m_00000000002930174373_3528144597_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000002930174373_3528144597");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
