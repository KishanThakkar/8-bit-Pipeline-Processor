/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000000956860246_2095992186_init();
    work_m_00000000000303365308_3238527249_init();
    work_m_00000000002826998522_1912483595_init();
    work_m_00000000000303365308_1240436890_init();
    work_m_00000000002826998522_3020866058_init();
    work_m_00000000003731162564_1664856687_init();
    work_m_00000000001465508480_3265002035_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000001465508480_3265002035");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
